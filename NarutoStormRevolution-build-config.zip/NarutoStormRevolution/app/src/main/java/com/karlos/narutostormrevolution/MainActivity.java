package com.karlos.narutostormrevolution;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

/**
 * Frontend prototype. This does not contain the Xenia/Xendroid emulation core.
 * Settings are saved locally but are not yet written into the emulator's config.
 */
public class MainActivity extends Activity {
    private static final int PICK_GAME = 41;
    private static final String PREFS = "nsr_settings";
    private static final String XENDROID_PACKAGE = "xendroid.compose.fork";
    private static final String XENDROID_ACTIVITY = "xendroid.compose.EmulatorHostActivity";
    private static final String XENDROID_ACTION = "xendroid.intent.action.xendroid";

    private SharedPreferences prefs;
    private TextView selectedFile;
    private TextView resolutionValue;
    private SeekBar resolutionBar;
    private Spinner fpsSpinner;
    private Uri selectedGame;

    private int bg = Color.rgb(16, 17, 20);
    private int panel = Color.rgb(29, 31, 37);
    private int orange = Color.rgb(249, 115, 22);
    private int text = Color.rgb(245, 245, 247);
    private int muted = Color.rgb(170, 174, 184);

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String uri = prefs.getString("game_uri", null);
        if (uri != null) selectedGame = Uri.parse(uri);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bg);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(24));
        scroll.addView(root);

        TextView eyebrow = label("ANDROID • XBOX 360 FRONTEND", 11, orange, true);
        root.addView(eyebrow);
        TextView title = label("NARUTO STORM\nREVOLUTION", 29, text, true);
        title.setPadding(0, dp(8), 0, dp(6));
        root.addView(title);
        root.addView(label("Projeto experimental • versão 0.1.0", 13, muted, false));

        LinearLayout warning = card();
        TextView warningText = label("IMPORTANTE\nEsta versão é apenas a interface inicial. Ela não inclui o núcleo de emulação e ainda não aplica resolução/FPS ao Xendroid+. Instale o Xendroid+ separadamente para testar a integração.", 13, text, false);
        warningText.setLineSpacing(dp(3), 1f);
        warning.addView(warningText);
        addSpace(root, 18);
        root.addView(warning);

        addSpace(root, 20);
        root.addView(sectionTitle("01  •  ARQUIVO DO JOGO"));
        LinearLayout gameCard = card();
        selectedFile = label(getSelectedFileLabel(), 13, muted, false);
        selectedFile.setPadding(0, 0, 0, dp(12));
        gameCard.addView(selectedFile);
        Button choose = button("Selecionar arquivo ISO / GOD / XEX");
        choose.setOnClickListener(v -> pickGame());
        gameCard.addView(choose);
        addSpace(root, 8);
        Button launch = button("Abrir jogo no Xendroid+");
        launch.setOnClickListener(v -> launchInXendroid());
        gameCard.addView(launch);
        root.addView(gameCard);

        addSpace(root, 20);
        root.addView(sectionTitle("02  •  DESEMPENHO"));
        LinearLayout perf = card();
        perf.addView(label("Resolução interna", 15, text, true));
        resolutionBar = new SeekBar(this);
        resolutionBar.setMax(75);
        resolutionBar.setProgress(prefs.getInt("resolution", 25)); // 50% default
        resolutionBar.setProgressTintList(android.content.res.ColorStateList.valueOf(orange));
        resolutionBar.setThumbTintList(android.content.res.ColorStateList.valueOf(orange));
        resolutionValue = label("50%", 14, orange, true);
        resolutionBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int percent = 25 + (progress / 25) * 25;
                resolutionValue.setText(percent + "%" + (percent == 50 ? "  • recomendado para o primeiro teste" : ""));
                if (fromUser) prefs.edit().putInt("resolution", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        perf.addView(resolutionBar);
        perf.addView(resolutionValue);
        addSpace(perf, 18);
        perf.addView(label("Limite de FPS", 15, text, true));
        fpsSpinner = new Spinner(this);
        String[] fps = {"20 FPS — priorizar estabilidade", "30 FPS — equilíbrio", "60 FPS — experimental"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, fps) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                TextView view = (TextView) super.getView(position, convertView, parent);
                view.setTextColor(text); view.setTextSize(14); return view;
            }
        };
        fpsSpinner.setAdapter(adapter);
        fpsSpinner.setSelection(prefs.getInt("fps_index", 0));
        fpsSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { prefs.edit().putInt("fps_index", pos).apply(); }
            @Override public void onNothingSelected(android.widget.AdapterView<?> p) {}
        });
        perf.addView(fpsSpinner);
        addSpace(perf, 10);
        perf.addView(label("Essas opções são salvas localmente. A integração que grava os valores no arquivo de configuração do núcleo ainda precisa ser implementada no fork.", 12, muted, false));
        root.addView(perf);

        addSpace(root, 20);
        root.addView(sectionTitle("03  •  DRIVER GRÁFICO"));
        LinearLayout driver = card();
        driver.addView(label("Driver atual: Vulkan do sistema", 15, text, true));
        addSpace(driver, 6);
        driver.addView(label("A GPU Adreno 618 do Galaxy A52 não é o alvo principal do Turnip no Xendroid+. Não instale drivers aleatórios: a seleção e a validação precisam ser integradas e testadas no aparelho.", 12, muted, false));
        Button driverInfo = button("Ver plano de integração do Turnip");
        driverInfo.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Turnip — compatibilidade não confirmada")
                .setMessage("O fork deve validar ABI arm64-v8a, biblioteca Vulkan, hash SHA-256 e GPU/driver do sistema. Para este protótipo, nenhum driver é baixado nem instalado.")
                .setPositiveButton("Entendi", null).show());
        addSpace(driver, 12);
        driver.addView(driverInfo);
        root.addView(driver);

        addSpace(root, 24);
        TextView footer = label("NÃO INCLUI ROM, ISO, BIOS OU ARQUIVOS DO JOGO. Use somente dumps feitos a partir de cópias que você possui.", 11, muted, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);
        setContentView(scroll);
        updateResolutionLabel();
    }

    private void updateResolutionLabel() {
        int percent = 25 + (resolutionBar.getProgress() / 25) * 25;
        resolutionValue.setText(percent + "%" + (percent == 50 ? "  • recomendado para o primeiro teste" : ""));
    }

    private void pickGame() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(intent, PICK_GAME); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "Não foi possível abrir o seletor de arquivos.", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_GAME && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedGame = data.getData();
            try { getContentResolver().takePersistableUriPermission(selectedGame, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (SecurityException ignored) {}
            prefs.edit().putString("game_uri", selectedGame.toString()).apply();
            selectedFile.setText(getSelectedFileLabel());
            Toast.makeText(this, "Arquivo selecionado. A compatibilidade depende do núcleo.", Toast.LENGTH_LONG).show();
        }
    }

    private void launchInXendroid() {
        if (selectedGame == null) {
            Toast.makeText(this, "Selecione primeiro um arquivo do jogo.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(XENDROID_ACTION);
        intent.setClassName(XENDROID_PACKAGE, XENDROID_ACTIVITY);
        intent.putExtra("game_uri", selectedGame.toString());
        intent.setData(selectedGame);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
        try { startActivity(intent); }
        catch (ActivityNotFoundException e) {
            new AlertDialog.Builder(this)
                .setTitle("Xendroid+ não encontrado")
                .setMessage("Instale uma versão compatível do Xendroid+ primeiro. A integração pode precisar de ajustes conforme a versão instalada.")
                .setPositiveButton("OK", null).show();
        }
    }

    private String getSelectedFileLabel() {
        if (selectedGame == null) return "Nenhum arquivo selecionado. Use uma cópia legítima do seu jogo.";
        String last = selectedGame.getLastPathSegment();
        return "Selecionado: " + (last == null ? selectedGame.toString() : last);
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(16), dp(16), dp(16), dp(16));
        layout.setBackgroundColor(panel);
        return layout;
    }
    private TextView sectionTitle(String s) { TextView t = label(s, 12, orange, true); t.setPadding(0, 0, 0, dp(10)); return t; }
    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(orange));
        b.setMinHeight(dp(48)); return b;
    }
    private void addSpace(LinearLayout parent, int heightDp) {
        View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, dp(heightDp)));
    }
    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
